package bgu.spl.Assignment3.Reactor;

public interface Message<T> {

}
